﻿// PkgCmdID.cs
// MUST match PkgCmdID.h

namespace OlegShilo.PropMan
{
    static class PkgCmdIDList
    {
        public const uint cmdidOpenCommand = 0x100;
        public const uint cmdidOpenConfigCommand = 0x101;
    };
}